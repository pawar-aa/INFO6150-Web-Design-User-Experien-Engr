import './App.css';
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router } from 'react-router-dom';

function App() {
  const [weatherData, setWeatherData] = useState(null);
  const [selectedDay, setSelectedDay] = useState(null);

  useEffect(() => {
    const apiKey = 'ed3e6c1bfc44b383ac1e2f719c7ce72f';
    const city = 'Boston';

    const fetchWeatherData = async () => {
      try {
        const response = await fetch(
          `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${apiKey}`
        );

        if (!response.ok) {
          throw new Error('Failed to fetch weather data');
        }

        const data = await response.json();
        setWeatherData(data);
        console.log('Complete API Response:', data);
      } catch (error) {
        console.error('Error fetching weather data:', error.message);
      }
    };

    fetchWeatherData();
  }, []);

  const today = new Date().toISOString().split('T')[0];

  const todayWeatherData = weatherData
    ? weatherData.list.filter((item) => item.dt_txt.includes(today))
    : [];

  const nextFiveDaysWeatherData = weatherData
    ? weatherData.list.filter((item) => {
        const itemDate = new Date(item.dt_txt).toISOString().split('T')[0];
        return itemDate !== today;
      })
    : [];

  const calculateAverage = (data, property) => {
    const total = data.reduce((acc, item) => acc + item.main[property], 0);
    return total / data.length;
  };

  const averageData = Object.keys(nextFiveDaysWeatherData.reduce((acc, item) => {
    const itemDate = new Date(item.dt_txt).toISOString().split('T')[0];
    if (!acc[itemDate]) {
      acc[itemDate] = [];
    }
    acc[itemDate].push(item);
    return acc;
  }, {})).map((date) => {
    const data = nextFiveDaysWeatherData.filter((item) =>
      new Date(item.dt_txt).toISOString().split('T')[0] === date
    );
    return {
      date,
      averageTemperature: calculateAverage(data, 'temp'),
      averageCondition: calculateAverage(data, 'temp'),
    };
  });

  const getConditionImage = (condition) => {
    const lowerCaseCondition = condition.toLowerCase();
    if (lowerCaseCondition.includes('rain')) {
      return 'https://cdn-icons-png.flaticon.com/128/2469/2469994.png'; // Rain image URL
    }
    if (lowerCaseCondition.includes('cloud')) {
      return 'https://cdn-icons-png.flaticon.com/128/3222/3222801.png'; // Cloud image URL
    }
    if (lowerCaseCondition.includes('clear')) {
      return 'https://cdn-icons-png.flaticon.com/128/6974/6974833.png'; // Clear sky image URL
    }
    if (lowerCaseCondition.includes('thunder')) {
      return 'https://cdn-icons-png.flaticon.com/128/3157/3157542.png'; // Thunder image URL
    }
    if (lowerCaseCondition.includes('snow')) {
      return 'https://cdn-icons-png.flaticon.com/128/6363/6363108.png'; // Snow image URL
    }
  };

  return (
    <Router>
      <div className="App">
        <header className="App-header">
          <h1>Weather Forecast App</h1>
        </header>
        <main>
          {/* Today's Forecast */}
          <h2>Today's Forecast {today} </h2>
          {todayWeatherData.length > 0 && (
            <div className="scroll-container">
              {todayWeatherData.map((item) => (
                <div className='forecast-card'
                >
                  <img
                    src={getConditionImage(item.weather[0].description)}
                    alt={item.weather[0].description}
                    className="weather-icon"
                  />
                  <p className="datetime">
                    {new Date(item.dt_txt).toLocaleTimeString('en-US', {
                      hour: 'numeric',
                      minute: 'numeric',
                      second: 'numeric',
                    })}
                  </p>
                  <p className="temperature">
                    Temp: {parseFloat(item.main.temp - 273.15).toFixed(2)}°C
                  </p>
                  <p className="description">
                    {item.weather[0].description}
                  </p>
                </div>
              ))}
            </div>
          )}

          {/* Next 5 Days Forecast */}
{averageData.length > 0 && (
  <div>
    <h2>Next 5 Days Forecast</h2>
    <div className="scroll-container">
      {averageData.map((item) => (
        <div
          key={item.date}
          className={`forecast-card ${selectedDay === item.date ? 'selected' : ''}`}
          onClick={() => setSelectedDay(item.date)}
        >
          <p className="date-weekday">
            <span className="datetime" >
              {new Date(item.date).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
              })}
            </span>
            <br />
            <span className="weekday">
              {new Date(item.date).toLocaleDateString('en-US', { weekday: 'long' })}
            </span>
          </p>
          <p className="temperature">
            Temp: {parseFloat(item.averageTemperature - 273.15).toFixed(2)}°C
          </p>
        </div>
      ))}
    </div>
  </div>
)}


          {selectedDay && selectedDay.hourly && (
            <div>
              <h2>Detailed Hourly Forecast for {selectedDay.date}</h2>
              <div className="scroll-container">
                {selectedDay.hourly.map((item) => (
                  <div key={item.dt} className="forecast-card">
                  <p className="datetime">
                    {new Date(item.dt_txt).toLocaleTimeString('en-US', {
                      hour: 'numeric',
                      minute: 'numeric',
                      second: 'numeric',
                    })}
                  </p>
                  <p className="temperature">
                    Temperature: {parseFloat(item.main.temp - 273.15).toFixed(2)}°C
                  </p>
                  <p className="description">Description: {item.weather[0].description}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        </main>
      </div>
    </Router>
  );
}

export default App;
