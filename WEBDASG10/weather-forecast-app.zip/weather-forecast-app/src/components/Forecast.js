import React from 'react';
import { Link } from 'react-router-dom';

const Forecast = ({ forecastData, onDayClick }) => {
  return (
    <div>
      <h1>5-Day Weather Forecast</h1>
      <ul>
        {forecastData.map((day) => (
          <li key={day.day}>
            <Link to={`/${day.day}`} onClick={() => onDayClick(day)}>
              <p>{day.day}</p>
              <p>High: {day.high - 273.15}°C</p>
              <p>Low: {day.low - 273.15}°C</p>
              <p>Condition: {day.condition}</p>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Forecast;
