import React from 'react';

const HourlyForecast = ({ hourlyData }) => {
  return (
    <div>
      <h1>Hourly Forecast</h1>
      <ul>
        {hourlyData.map((hour, index) => (
          <li key={index}>
            <p>{hour.time}</p>
            <p>Temperature: {hour.temperature}°C</p>
            {/* Add other hourly details */}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default HourlyForecast;
